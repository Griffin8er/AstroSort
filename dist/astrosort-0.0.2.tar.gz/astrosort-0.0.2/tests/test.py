from AstroSort import field_of_view

result = field_of_view.required_fov_from_names(
    ["NGC 3031", "NGC 3034"],
    setup_X=2.59,
    setup_Y=2.59,
    padding_percentage=5
)